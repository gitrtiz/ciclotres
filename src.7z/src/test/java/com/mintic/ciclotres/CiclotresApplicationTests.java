package com.mintic.ciclotres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiclotresApplicationTests {

	@Test
	void contextLoads() {
	}

}
